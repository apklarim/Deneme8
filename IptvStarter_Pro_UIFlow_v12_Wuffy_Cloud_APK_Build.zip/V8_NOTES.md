# v8 UI Flow Güncellemesi

Bu sürüm, v7 çalışan sürümünün üzerine aşağıdaki değişiklikleri ekler:

- Ayarlar ekranı M3U / Xtream / MAG olarak 3 sekmeye ayrıldı.
- Link bölümündeki 2'li ve 4'lü ekran butonları kaldırıldı.
- Yanlış M3U veya Xtream bağlantısı girildiğinde eski link/kayıt hemen bozulmaz; önce bağlantı denenir, başarılıysa kayıt güncellenir.
- M3U linki `get.php?username=...&password=...` formatında Xtream'e benziyorsa kullanıcıya Xtream olarak mı M3U olarak mı kaydedileceği sorulur.
- Ana ekrandan Canlı / Film / Dizi seçildiğinde player açılır ve gruplar otomatik gösterilir.
- Player'da çift dokunma veya kumandada OK/Enter çift basma grup/kanal listesini açar.
- Player'da açık listeye dışarıdan dokununca liste kapanır.
- Kanal listesi Liste / Resimli Liste modunda çalışır; resimli modda logo URL'si olan kanallarda logo yüklenir.
- Buton ve liste seçim renkleri TV kumandası için daha belirgin hale getirildi.
- Player alt hızlı barda geri simgesi ve renkli çoklu ekran/grup simgeleri eklendi.
- VOD/dizi oynatmada Media3 player kontrol çubuğu ile sarma ve süre göstergesi kullanılabilir.

APK üretimi için GitHub Actions workflow dosyası korunmuştur.
