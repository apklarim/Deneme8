# GitHub ZIP ile v11 APK üretme

Repo içine şu ZIP'i tek dosya olarak yükleyin:

```text
IptvStarter_Pro_UIFlow_v11_Cloud_APK_Build.zip
```

Sonra GitHub'da şu dosyayı oluşturun:

```text
.github/workflows/build-v11-from-zip.yml
```

İçerik:

```yaml
name: Build v11 APK From ZIP

on:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repo
        uses: actions/checkout@v4

      - name: Unzip project
        run: |
          unzip IptvStarter_Pro_UIFlow_v11_Cloud_APK_Build.zip -d project
          find project -maxdepth 3 -type f | head -80

      - name: Find project root
        run: |
          PROJECT_DIR=$(find project -name "settings.gradle.kts" -exec dirname {} \; | head -1)
          echo "PROJECT_DIR=$PROJECT_DIR" >> $GITHUB_ENV
          echo "Project root: $PROJECT_DIR"

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Android SDK packages
        run: |
          yes | sdkmanager --licenses
          sdkmanager "platforms;android-35" "build-tools;35.0.0" "platform-tools"

      - name: Create Gradle wrapper if missing
        working-directory: ${{ env.PROJECT_DIR }}
        run: |
          if [ ! -f ./gradlew ]; then
            gradle wrapper --gradle-version 8.9
          fi
          chmod +x ./gradlew

      - name: Build debug APK
        working-directory: ${{ env.PROJECT_DIR }}
        run: ./gradlew assembleDebug --stacktrace

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: IPTV-Starter-v11-Debug-APK
          path: ${{ env.PROJECT_DIR }}/app/build/outputs/apk/debug/*.apk
```

Çalıştırma:

```text
Actions > Build v11 APK From ZIP > Run workflow
```
