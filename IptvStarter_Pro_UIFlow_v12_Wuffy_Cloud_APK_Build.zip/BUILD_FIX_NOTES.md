# Build Fix Notes

## Çözülen hata

Android Studio'nun verdiği hata:

```text
Dependency 'androidx.media3:media3-exoplayer-hls:1.10.1' requires compileSdk 36 or later.
:app is currently compiled against android-35.
```

## Uygulanan çözüm

Bu pakette `compileSdk = 35` korunmuştur ve Media3 sürümleri `1.10.1` yerine `1.9.4` yapılmıştır.

Böylece Android SDK 36 kurulu olmayan veya AGP 8.7.x ile daha stabil çalışan bilgisayarlarda Gradle Sync daha sorunsuz olur.

```kotlin
implementation("androidx.media3:media3-exoplayer:1.9.4")
implementation("androidx.media3:media3-exoplayer-hls:1.9.4")
implementation("androidx.media3:media3-ui:1.9.4")
```

## Alternatif çözüm

Media3 `1.10.1` kullanmak istersen:

```kotlin
compileSdk = 36
```

yapman ve Android Studio SDK Manager içinden Android API 36 platformunu kurman gerekir.

Başlangıç projesi için bu pakette daha uyumlu yol seçildi: `compileSdk 35 + Media3 1.9.4`.
