package com.apklarim.iptvstarter.ui.adapters

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.apklarim.iptvstarter.data.local.SourceEntity
import com.apklarim.iptvstarter.ui.dp

class SourceAdapter(
    private val onClick: (SourceEntity?) -> Unit,
    private val onLongClick: (SourceEntity) -> Unit
) : ListAdapter<SourceEntity, SourceAdapter.SourceViewHolder>(Diff) {

    var selectedId: Long? = null
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SourceViewHolder {
        val row = LinearLayout(parent.context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(14), dp(13), dp(14), dp(13))
            layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(dp(4), dp(4), dp(8), dp(4))
            }
        }
        return SourceViewHolder(row, onClick, onLongClick)
    }

    override fun onBindViewHolder(holder: SourceViewHolder, position: Int) {
        holder.bind(getItem(position), selectedId == getItem(position).id)
    }

    class SourceViewHolder(
        private val root: LinearLayout,
        private val onClick: (SourceEntity?) -> Unit,
        private val onLongClick: (SourceEntity) -> Unit
    ) : RecyclerView.ViewHolder(root) {
        private val title = TextView(root.context).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            maxLines = 1
            typeface = Typeface.DEFAULT_BOLD
        }

        init { root.addView(title) }

        fun bind(source: SourceEntity, selected: Boolean) {
            title.text = source.name.ifBlank { source.label() }
            root.background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_pressed), bg(root.dp(14), Color.rgb(230, 145, 35), Color.WHITE, root.dp(2)))
                addState(intArrayOf(android.R.attr.state_focused), bg(root.dp(14), Color.rgb(205, 128, 30), Color.rgb(255, 235, 160), root.dp(2)))
                addState(intArrayOf(), bg(root.dp(14), if (selected) Color.rgb(76, 58, 34) else Color.rgb(18, 31, 49), if (selected) Color.rgb(255, 204, 120) else Color.rgb(39, 54, 76), root.dp(1)))
            }
            root.setOnClickListener { onClick(source) }
            root.setOnLongClickListener { onLongClick(source); true }
        }

        private fun bg(radius: Int, color: Int, stroke: Int, strokeWidth: Int) = GradientDrawable().apply {
            cornerRadius = radius.toFloat()
            setColor(color)
            setStroke(strokeWidth, stroke)
        }
    }

    object Diff : DiffUtil.ItemCallback<SourceEntity>() {
        override fun areItemsTheSame(oldItem: SourceEntity, newItem: SourceEntity) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: SourceEntity, newItem: SourceEntity) = oldItem == newItem
    }
}
