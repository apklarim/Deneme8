package com.apklarim.iptvstarter.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sources")
data class SourceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,
    val url: String,
    val username: String? = null,
    val password: String? = null,
    val magMac: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun label(): String = when (type) {
        TYPE_M3U_URL -> "M3U"
        TYPE_M3U_FILE -> "Dosya"
        TYPE_XTREAM -> "Xtream"
        TYPE_MAG -> "MAG"
        else -> type
    }

    companion object {
        const val TYPE_M3U_URL = "M3U_URL"
        const val TYPE_M3U_FILE = "M3U_FILE"
        const val TYPE_XTREAM = "XTREAM"
        const val TYPE_MAG = "MAG"
    }
}
