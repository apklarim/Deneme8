package com.apklarim.iptvstarter.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "channels",
    indices = [Index("sourceId"), Index("groupName"), Index("name")]
)
data class ChannelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceId: Long,
    val name: String,
    val logo: String?,
    val groupName: String?,
    val streamUrl: String,
    val mediaType: String = MEDIA_LIVE,
    val isFavorite: Boolean = false,
    val lastPlayedAt: Long? = null
) {
    companion object {
        const val MEDIA_LIVE = "LIVE"
        const val MEDIA_VOD = "VOD"
        const val MEDIA_SERIES = "SERIES"
    }
}
