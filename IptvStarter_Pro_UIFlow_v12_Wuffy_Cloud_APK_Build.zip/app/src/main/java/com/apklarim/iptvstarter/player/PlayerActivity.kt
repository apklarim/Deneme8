package com.apklarim.iptvstarter.player

import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.Rational
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.load
import com.apklarim.iptvstarter.data.local.AppDatabase
import com.apklarim.iptvstarter.data.local.ChannelEntity
import com.apklarim.iptvstarter.ui.dp
import com.apklarim.iptvstarter.ui.enableImmersiveFullscreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var titleView: TextView
    private lateinit var errorView: TextView
    private lateinit var overlay: FrameLayout
    private var playlist: List<ChannelEntity> = emptyList()
    private var currentIndex = -1
    private var currentSourceId: Long? = null
    private var lastTapAt = 0L
    private var lastCenterAt = 0L
    private var mediaType: String = ChannelEntity.MEDIA_LIVE
    private var listModeImage = false
    private var lastGroupName: String? = null
    private var showingChannels = false
    private var numberBuffer = ""
    private var currentRawUrl = ""
    private var currentTitle = ""
    private var currentChannelId: Long = -1L
    private var fallbackTried = false
    private var forceInternalOnce = false
    private val numberHandler = Handler(Looper.getMainLooper())
    private val numberRunnable = Runnable { playNumberBuffer() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching { enableImmersiveFullscreen() }
        currentSourceId = intent.getLongExtra(EXTRA_SOURCE_ID, -1L).takeIf { it > 0 }
        mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE) ?: ChannelEntity.MEDIA_LIVE
        lastGroupName = prefs().getString(lastGroupKey(), null)
        val channelId = intent.getLongExtra(EXTRA_CHANNEL_ID, -1L)
        val rawUrl = intent.getStringExtra(EXTRA_STREAM_URL).orEmpty()
        val rawTitle = intent.getStringExtra(EXTRA_TITLE) ?: "IPTV Player"
        val autoShowGroups = intent.getBooleanExtra(EXTRA_AUTO_SHOW_GROUPS, false)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); isFocusable = true; isFocusableInTouchMode = true; fitsSystemWindows = false }
        playerView = PlayerView(this).apply {
            keepScreenOn = true
            useController = true
            controllerAutoShow = true
            controllerHideOnTouch = true
            setControllerShowTimeoutMs(if (mediaType == ChannelEntity.MEDIA_LIVE) 3500 else 5000)
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
        }
        root.addView(playerView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        titleView = TextView(this).apply { text = rawTitle; setTextColor(Color.WHITE); textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(16), dp(10), dp(16), dp(10)); background = pill(Color.argb(150,0,0,0)) }
        root.addView(titleView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply { setMargins(dp(12), dp(12), dp(12), dp(12)) })
        errorView = TextView(this).apply { visibility = View.GONE; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER; setPadding(dp(22), dp(16), dp(22), dp(16)); background = pill(Color.argb(190, 55, 10, 10)) }
        root.addView(errorView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply { setMargins(dp(24), dp(24), dp(24), dp(24)) })

        val quickBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(12), dp(8), dp(12), dp(8)); background = pill(Color.argb(180,5,13,26)); visibility = View.GONE }
        quickBar.addView(controlButton("↩ Geri") { finish() })
        quickBar.addView(controlButton("🪟 PIP") { enterPipMode() })
        quickBar.addView(controlButton("🟦 2'li") { openMulti(2) })
        quickBar.addView(controlButton("🟩 4'lü") { openMulti(4) })
        quickBar.addView(controlButton("📺 Kanallar") { showLastGroupOrGroups() })
        quickBar.addView(controlButton("📚 Gruplar") { showGroups(includeHidden = false) })
        root.addView(quickBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { setMargins(0,0,0,dp(18)) })

        overlay = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(Color.argb(150, 0, 0, 0)); isClickable = true; setOnClickListener { hideOverlay() } }
        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        playerView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val now = System.currentTimeMillis()
                if (overlay.visibility == View.VISIBLE) hideOverlay()
                else if (now - lastTapAt < 420) showLastGroupOrGroups()
                else quickBar.visibility = if (quickBar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                lastTapAt = now
            }
            false
        }
        setContentView(root)
        root.requestFocus()

        lifecycleScope.launch {
            loadPlaylist(channelId)
            if (playlist.isNotEmpty()) {
                if (currentIndex < 0) currentIndex = 0
                playChannel(playlist[currentIndex])
                if (autoShowGroups) showLastGroupOrGroups()
            } else playRaw(rawUrl, rawTitle)
        }
    }

    private suspend fun loadPlaylist(channelId: Long) {
        runCatching {
            withContext(Dispatchers.IO) { AppDatabase.get(this@PlayerActivity).channelDao().getChannelsByType(currentSourceId, mediaType, 100000) }
        }.onSuccess { list ->
            playlist = list.sortedWith(compareBy<ChannelEntity> { it.groupName ?: "Genel" }.thenBy { it.name })
            currentIndex = playlist.indexOfFirst { it.id == channelId }
            if (lastGroupName.isNullOrBlank() && playlist.isNotEmpty()) lastGroupName = groupOf(playlist.first())
        }
    }

    private fun playRelative(delta: Int) {
        if (playlist.isEmpty()) { Toast.makeText(this, "Liste hazır değil", Toast.LENGTH_SHORT).show(); return }
        if (currentIndex < 0) currentIndex = 0
        currentIndex = (currentIndex + delta + playlist.size) % playlist.size
        playChannel(playlist[currentIndex])
    }

    private fun playChannel(channel: ChannelEntity) {
        titleView.text = "${indexLabel(channel)} ${channel.name.ifBlank { "İsimsiz Kanal" }}".trim()
        currentIndex = playlist.indexOfFirst { it.id == channel.id }.takeIf { it >= 0 } ?: currentIndex
        currentChannelId = channel.id
        lastGroupName = groupOf(channel)
        prefs().edit().putString(lastGroupKey(), lastGroupName).putLong(lastChannelKey(), channel.id).apply()
        hideOverlay()
        playRaw(channel.streamUrl, titleView.text.toString(), channel.id)
        lifecycleScope.launch { runCatching { withContext(Dispatchers.IO) { AppDatabase.get(this@PlayerActivity).channelDao().markPlayed(channel.id) } } }
    }

    private fun playRaw(rawUrl: String, title: String, channelId: Long = -1L) {
        val url = rawUrl.substringBefore('|').trim()
        currentRawUrl = url
        currentTitle = title
        currentChannelId = channelId
        fallbackTried = false
        titleView.text = title
        errorView.visibility = View.GONE
        if (!isPlayableUrl(url)) { showError("Yayın linki geçersiz veya desteklenmiyor."); return }

        val mode = if (forceInternalOnce) PLAYER_INTERNAL else preferredPlayerMode(channelId)
        forceInternalOnce = false
        when (mode) {
            PLAYER_WUFFY -> { openWuffy(url, title, finishAfter = false); return }
            PLAYER_EXTERNAL -> { openExternalChooser(url, title, finishAfter = false); return }
        }

        runCatching {
            val exo = player ?: ExoPlayer.Builder(this).build().also { p ->
                player = p; playerView.player = p
                p.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) { handleInternalPlayerError(error) }
                })
            }
            exo.stop(); exo.clearMediaItems(); exo.setMediaItem(MediaItem.fromUri(Uri.parse(url))); exo.prepare(); exo.playWhenReady = true
        }.onFailure { handleInternalStartFailure(it) }
    }

    private fun handleInternalPlayerError(error: PlaybackException) {
        val msg = "Dahili player açamadı: ${error.errorCodeName}"
        if (preferredPlayerMode(currentChannelId) == PLAYER_AUTO && !fallbackTried) {
            fallbackTried = true
            errorView.text = "$msg\nWuffy deneniyor..."
            errorView.visibility = View.VISIBLE
            openWuffy(currentRawUrl, currentTitle, finishAfter = false)
        } else showError(msg)
    }

    private fun handleInternalStartFailure(error: Throwable) {
        val msg = "Dahili player başlatılamadı: ${error.message ?: error.javaClass.simpleName}"
        if (preferredPlayerMode(currentChannelId) == PLAYER_AUTO && !fallbackTried) {
            fallbackTried = true
            errorView.text = "$msg\nWuffy deneniyor..."
            errorView.visibility = View.VISIBLE
            openWuffy(currentRawUrl, currentTitle, finishAfter = false)
        } else showError(msg)
    }

    private fun showLastGroupOrGroups() {
        val group = lastGroupName?.takeIf { g -> playlist.any { groupOf(it) == g } && !hiddenGroups().contains(g) }
        if (group != null) showChannels(group) else showGroups(includeHidden = false)
    }

    private fun showGroups(includeHidden: Boolean = false) {
        if (playlist.isEmpty()) { Toast.makeText(this, "Liste boş", Toast.LENGTH_SHORT).show(); return }
        showingChannels = false
        val hidden = hiddenGroups()
        val normalGroups = playlist.map { groupOf(it) }.distinct().sorted().filter { includeHidden || !hidden.contains(it) }
        val groups = if (!includeHidden && playlist.any { it.isFavorite }) listOf(FAVORITES_GROUP) + normalGroups else normalGroups
        val title = if (includeHidden) "Gizli Gruplar" else "Gruplar"
        renderOverlay(title, groups, topActions = listOf(
            "↩ Player" to { hideOverlay() },
            "👁 Gizliler" to { showGroups(includeHidden = true) },
            "Liste/Resimli" to { listModeImage = !listModeImage; showGroups(includeHidden) }
        ), onLongItem = { group -> if (group != FAVORITES_GROUP) groupOptions(group) }) { group ->
            if (group != FAVORITES_GROUP && adultGroups().contains(group)) askAdultPin { showChannels(group) } else showChannels(group)
        }
    }

    private fun showChannels(group: String) {
        if (group != FAVORITES_GROUP && hiddenGroups().contains(group)) {
            Toast.makeText(this, "Bu grup gizli. Önce Gruplar > Gizliler bölümünden gösterin.", Toast.LENGTH_LONG).show()
            return
        }
        lastGroupName = group
        prefs().edit().putString(lastGroupKey(), group).apply()
        showingChannels = true
        val items = if (group == FAVORITES_GROUP) playlist.filter { it.isFavorite } else playlist.filter { groupOf(it) == group }
        renderChannels("$group (${items.size})", items)
    }

    private fun renderOverlay(title: String, items: List<String>, topActions: List<Pair<String, () -> Unit>> = emptyList(), onLongItem: ((String) -> Unit)? = null, onItem: (String) -> Unit) {
        overlay.removeAllViews(); overlay.visibility = View.VISIBLE
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = pill(Color.argb(238, 7, 20, 36)); isClickable = true }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(controlButton("←") { hideOverlay() })
        top.addView(TextView(this).apply { text = title; setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(10),0,dp(8),dp(10)) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        panel.addView(top)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        topActions.forEach { pair -> actions.addView(controlButton(pair.first, pair.second)) }
        if (topActions.isNotEmpty()) panel.addView(actions)
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = true }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        items.forEach { item ->
            val prefix = when {
                item == FAVORITES_GROUP -> ""
                hiddenGroups().contains(item) -> "🙈 "
                adultGroups().contains(item) -> "🔒 "
                else -> ""
            }
            list.addView(menuRow(prefix + item, null) { onItem(item) }.apply {
                setOnLongClickListener { onLongItem?.invoke(item); true }
            })
        }
        panel.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val panelWidth = if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) dp(430) else ViewGroup.LayoutParams.MATCH_PARENT
        overlay.addView(panel, FrameLayout.LayoutParams(panelWidth, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END))
    }

    private fun renderChannels(title: String, items: List<ChannelEntity>) {
        overlay.removeAllViews(); overlay.visibility = View.VISIBLE
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = pill(Color.argb(238, 7, 20, 36)); isClickable = true }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(controlButton("←") { showGroups(includeHidden = false) })
        top.addView(TextView(this).apply { text = title; setTextColor(Color.WHITE); textSize = 21f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(10),0,dp(8),dp(10)) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        panel.addView(top)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(controlButton("← Gruplar") { showGroups(includeHidden = false) })
        actions.addView(controlButton(if (listModeImage) "☰ Liste" else "▦ Resimli Liste") { listModeImage = !listModeImage; renderChannels(title, items) })
        panel.addView(actions)

        val search = EditText(this).apply {
            hint = "🔎 Kanal ara"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(180, 205, 230))
            textSize = 15f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = selectablePill(Color.rgb(12, 28, 48), Color.rgb(42, 82, 124))
        }
        panel.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(6), 0, dp(6)) })

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = true }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)

        fun fill(query: String) {
            list.removeAllViews()
            val q = query.trim().lowercase()
            val filtered = if (q.isBlank()) items else items.filter { it.name.lowercase().contains(q) || groupOf(it).lowercase().contains(q) }
            if (filtered.isEmpty()) {
                list.addView(TextView(this).apply { text = "Sonuç bulunamadı"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER; setPadding(dp(10), dp(20), dp(10), dp(20)) })
                return
            }
            filtered.forEach { ch -> list.addView(channelRow(ch)) }
        }
        fill("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { fill(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })

        panel.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val panelWidth = if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) dp(500) else ViewGroup.LayoutParams.MATCH_PARENT
        overlay.addView(panel, FrameLayout.LayoutParams(panelWidth, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END))
    }

    private fun channelRow(ch: ChannelEntity): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(10), if (listModeImage) dp(10) else dp(8), dp(10), if (listModeImage) dp(10) else dp(8))
            background = selectablePill(if (ch.id == playlist.getOrNull(currentIndex)?.id) Color.rgb(35, 68, 104) else Color.rgb(16, 31, 50), Color.rgb(52, 96, 146))
            setOnClickListener { playChannel(ch) }
            setOnLongClickListener { showAlternativePlayer(ch); true }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(4), 0, dp(4)) }
        }
        if (listModeImage && !ch.logo.isNullOrBlank()) {
            row.addView(ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; load(ch.logo) { crossfade(true) } }, LinearLayout.LayoutParams(dp(54), dp(40)).apply { setMargins(0, 0, dp(10), 0) })
        }
        val pos = playlist.indexOfFirst { it.id == ch.id }.takeIf { it >= 0 }?.plus(1) ?: 0
        val name = if (pos > 0) "$pos. ${ch.name.ifBlank { "İsimsiz Kanal" }}" else ch.name.ifBlank { "İsimsiz Kanal" }
        row.addView(TextView(this).apply {
            text = if (listModeImage || ch.logo.isNullOrBlank()) name else "▣  $name"
            setTextColor(Color.WHITE)
            textSize = if (listModeImage) 17f else 16f
            maxLines = 1
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = if (ch.isFavorite) "★" else "☆"
            setTextColor(if (ch.isFavorite) Color.rgb(255, 214, 80) else Color.rgb(190, 210, 230))
            textSize = 28f
            gravity = Gravity.CENTER
            isFocusable = true
            isClickable = true
            setPadding(dp(10), 0, dp(10), 0)
            background = selectablePill(Color.rgb(22,52,72), Color.rgb(52,96,146))
            setOnClickListener { toggleFavorite(ch) }
        }, LinearLayout.LayoutParams(dp(54), dp(46)))
        return row
    }

    private fun toggleFavorite(channel: ChannelEntity) {
        val newValue = !channel.isFavorite
        playlist = playlist.map { if (it.id == channel.id) it.copy(isFavorite = newValue) else it }
        lifecycleScope.launch { runCatching { withContext(Dispatchers.IO) { AppDatabase.get(this@PlayerActivity).channelDao().setFavorite(channel.id, newValue) } } }
        Toast.makeText(this, if (newValue) "Favorilere eklendi" else "Favorilerden çıkarıldı", Toast.LENGTH_SHORT).show()
        showChannels(lastGroupName ?: groupOf(channel))
    }

    private fun groupOptions(group: String) {
        val hidden = hiddenGroups().contains(group)
        val adult = adultGroups().contains(group)
        val opts = arrayOf(
            if (hidden) "Göster" else "Gizle",
            if (adult) "Adult şifresini kaldır" else "Adult şifresi koy",
            "İptal"
        )
        AlertDialog.Builder(this).setTitle(group).setItems(opts) { _, which ->
            when (which) {
                0 -> { if (hidden) unhideGroup(group) else hideGroup(group); showGroups(includeHidden = hidden) }
                1 -> { if (adult) removeAdultGroup(group) else setAdultGroupWithPin(group) }
            }
        }.show()
    }

    private fun setAdultGroupWithPin(group: String) {
        val input = EditText(this).apply { hint = "4 haneli şifre"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("Adult şifresi").setMessage("Bu grup için şifre belirle: $group").setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val pin = input.text.toString().trim()
                if (pin.length < 4) Toast.makeText(this, "En az 4 haneli şifre girin", Toast.LENGTH_LONG).show()
                else { prefs().edit().putString(adultPinKey(), pin).putStringSet(adultGroupsKey(), adultGroups() + group).apply(); Toast.makeText(this, "Adult şifresi eklendi", Toast.LENGTH_SHORT).show(); showGroups(false) }
            }.setNegativeButton("Vazgeç", null).show()
    }

    private fun askAdultPin(onOk: () -> Unit) {
        val pin = prefs().getString(adultPinKey(), null)
        if (pin.isNullOrBlank()) { onOk(); return }
        val input = EditText(this).apply { hint = "Şifre"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("Adult şifresi").setView(input)
            .setPositiveButton("Aç") { _, _ -> if (input.text.toString() == pin) onOk() else Toast.makeText(this, "Şifre yanlış", Toast.LENGTH_LONG).show() }
            .setNegativeButton("Vazgeç", null).show()
    }

    private fun hideGroup(group: String) { prefs().edit().putStringSet(hiddenGroupsKey(), hiddenGroups() + group).apply() }
    private fun unhideGroup(group: String) { prefs().edit().putStringSet(hiddenGroupsKey(), hiddenGroups() - group).apply() }
    private fun removeAdultGroup(group: String) { prefs().edit().putStringSet(adultGroupsKey(), adultGroups() - group).apply(); Toast.makeText(this, "Adult koruması kaldırıldı", Toast.LENGTH_SHORT).show(); showGroups(false) }
    private fun hiddenGroups(): Set<String> = prefs().getStringSet(hiddenGroupsKey(), emptySet()) ?: emptySet()
    private fun adultGroups(): Set<String> = prefs().getStringSet(adultGroupsKey(), emptySet()) ?: emptySet()

    private fun menuRow(text: String, logo: String?, click: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(14), if (listModeImage) dp(12) else dp(10), dp(14), if (listModeImage) dp(12) else dp(10))
            background = selectablePill(Color.rgb(16, 31, 50), Color.rgb(62, 98, 142))
            setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(4), 0, dp(4)) }
        }
        if (listModeImage && !logo.isNullOrBlank()) {
            row.addView(ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; load(logo) { crossfade(true) } }, LinearLayout.LayoutParams(dp(54), dp(40)).apply { setMargins(0, 0, dp(12), 0) })
        }
        row.addView(TextView(this).apply {
            this.text = if (logo.isNullOrBlank() || listModeImage) text else "▣  $text"
            setTextColor(Color.WHITE)
            textSize = if (listModeImage) 17f else 16f
            maxLines = 1
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    private fun showAlternativePlayer(channel: ChannelEntity) {
        val opts = arrayOf(
            "Dahili player ile aç",
            "Wuffy Player ile aç",
            "Harici player seç",
            "Bu kanal için her zaman Wuffy",
            "Bu link için her zaman Wuffy",
            "Bu kanal varsayılanını temizle"
        )
        AlertDialog.Builder(this).setTitle(channel.name).setItems(opts) { _, which ->
            val clean = channel.streamUrl.substringBefore('|').trim()
            when (which) {
                0 -> { setOneShotInternalAndPlay(channel) }
                1 -> openWuffy(clean, channel.name, finishAfter = false)
                2 -> openExternalChooser(clean, channel.name, finishAfter = false)
                3 -> { setChannelMode(channel.id, PLAYER_WUFFY); Toast.makeText(this, "Bu kanal Wuffy ile açılacak", Toast.LENGTH_SHORT).show(); playChannel(channel) }
                4 -> { setSourceMode(PLAYER_WUFFY); Toast.makeText(this, "Bu link Wuffy ile açılacak", Toast.LENGTH_SHORT).show(); playChannel(channel) }
                5 -> { clearChannelMode(channel.id); Toast.makeText(this, "Kanal varsayılanı temizlendi", Toast.LENGTH_SHORT).show() }
            }
        }.show()
    }

    private fun setOneShotInternalAndPlay(channel: ChannelEntity) {
        val old = preferredPlayerMode(channel.id)
        forceInternalOnce = true
        playChannel(channel)
        if (old == PLAYER_WUFFY || old == PLAYER_EXTERNAL) Toast.makeText(this, "Bu açılışta dahili player denendi", Toast.LENGTH_SHORT).show()
    }

    private fun openWuffy(url: String, title: String, finishAfter: Boolean) {
        if (url.isBlank()) { showError("Wuffy için yayın linki boş"); return }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(url), "video/*")
            setPackage(WUFFY_PACKAGE)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra("title", title)
            putExtra(Intent.EXTRA_TITLE, title)
        }
        runCatching {
            startActivity(intent)
            Toast.makeText(this, "Wuffy Player açılıyor", Toast.LENGTH_SHORT).show()
            if (finishAfter) finish()
        }.onFailure {
            Toast.makeText(this, "Wuffy bulunamadı, harici player seçimi açılıyor", Toast.LENGTH_LONG).show()
            openExternalChooser(url, title, finishAfter)
        }
    }

    private fun openExternalChooser(url: String, title: String, finishAfter: Boolean) {
        if (url.isBlank()) { showError("Harici player için yayın linki boş"); return }
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(url), "video/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra("title", title)
            putExtra(Intent.EXTRA_TITLE, title)
        }
        runCatching {
            startActivity(Intent.createChooser(viewIntent, "Player seç"))
            if (finishAfter) finish()
        }.onFailure {
            val fallback = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { startActivity(Intent.createChooser(fallback, "Player seç")) }
                .onFailure { showError("Harici player açılamadı") }
        }
    }

    private fun openMulti(count: Int) {
        val sid = currentSourceId ?: return
        startActivity(Intent(this, MultiPlayerActivity::class.java).apply { putExtra(MultiPlayerActivity.EXTRA_COUNT, count); putExtra(MultiPlayerActivity.EXTRA_SOURCE_ID, sid); putExtra(MultiPlayerActivity.EXTRA_MEDIA_TYPE, mediaType) })
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            runCatching { enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()) }
                .onFailure { Toast.makeText(this, "PIP açılamadı", Toast.LENGTH_SHORT).show() }
        } else Toast.makeText(this, "PIP için Android 8+ gerekir", Toast.LENGTH_SHORT).show()
    }

    private fun hideOverlay() { overlay.visibility = View.GONE; overlay.removeAllViews(); showingChannels = false }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        val digit = keyToDigit(event.keyCode)
        if (digit != null && overlay.visibility != View.VISIBLE) { appendDigit(digit); return true }
        return when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> { playRelative(1); true }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { playRelative(-1); true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (overlay.visibility == View.VISIBLE) super.dispatchKeyEvent(event) else {
                    val now = System.currentTimeMillis()
                    if (now - lastCenterAt < 520) showLastGroupOrGroups() else player?.let { if (it.isPlaying) it.pause() else it.play() }
                    lastCenterAt = now
                    true
                }
            }
            KeyEvent.KEYCODE_BACK -> {
                if (overlay.visibility == View.VISIBLE) { if (showingChannels) showGroups(false) else hideOverlay(); true } else { finish(); true }
            }
            else -> super.dispatchKeyEvent(event)
        }
    }

    private fun appendDigit(digit: Int) { numberBuffer += digit.toString(); Toast.makeText(this, "Kanal no: $numberBuffer", Toast.LENGTH_SHORT).show(); numberHandler.removeCallbacks(numberRunnable); numberHandler.postDelayed(numberRunnable, 1150) }
    private fun playNumberBuffer() { val n = numberBuffer.toIntOrNull(); numberBuffer = ""; if (n == null || n < 1 || n > playlist.size) Toast.makeText(this, "Kanal numarası bulunamadı", Toast.LENGTH_SHORT).show() else { currentIndex = n - 1; playChannel(playlist[currentIndex]) } }
    private fun keyToDigit(keyCode: Int): Int? = when (keyCode) { KeyEvent.KEYCODE_0, KeyEvent.KEYCODE_NUMPAD_0 -> 0; KeyEvent.KEYCODE_1, KeyEvent.KEYCODE_NUMPAD_1 -> 1; KeyEvent.KEYCODE_2, KeyEvent.KEYCODE_NUMPAD_2 -> 2; KeyEvent.KEYCODE_3, KeyEvent.KEYCODE_NUMPAD_3 -> 3; KeyEvent.KEYCODE_4, KeyEvent.KEYCODE_NUMPAD_4 -> 4; KeyEvent.KEYCODE_5, KeyEvent.KEYCODE_NUMPAD_5 -> 5; KeyEvent.KEYCODE_6, KeyEvent.KEYCODE_NUMPAD_6 -> 6; KeyEvent.KEYCODE_7, KeyEvent.KEYCODE_NUMPAD_7 -> 7; KeyEvent.KEYCODE_8, KeyEvent.KEYCODE_NUMPAD_8 -> 8; KeyEvent.KEYCODE_9, KeyEvent.KEYCODE_NUMPAD_9 -> 9; else -> null }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean { runCatching { enableImmersiveFullscreen() }; return super.dispatchTouchEvent(ev) }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) runCatching { enableImmersiveFullscreen() } }
    override fun onStop() { super.onStop(); player?.release(); player = null }

    private fun groupOf(ch: ChannelEntity) = ch.groupName?.ifBlank { "Genel" } ?: "Genel"
    private fun indexLabel(ch: ChannelEntity): String = playlist.indexOfFirst { it.id == ch.id }.takeIf { it >= 0 }?.plus(1)?.let { "$it." }.orEmpty()
    private fun prefs() = getSharedPreferences("player_prefs_v12", MODE_PRIVATE)
    private fun lastGroupKey() = "last_group_${currentSourceId ?: 0}_$mediaType"
    private fun lastChannelKey() = "last_channel_${currentSourceId ?: 0}_$mediaType"
    private fun hiddenGroupsKey() = "hidden_groups_${currentSourceId ?: 0}_$mediaType"
    private fun adultGroupsKey() = "adult_groups_${currentSourceId ?: 0}_$mediaType"
    private fun adultPinKey() = "adult_pin_${currentSourceId ?: 0}"
    private fun preferredPlayerMode(channelId: Long = currentChannelId): String {
        val p = getSharedPreferences(PLAYER_PREFS, MODE_PRIVATE)
        if (channelId > 0) p.getString("channel_mode_$channelId", null)?.let { return it }
        currentSourceId?.takeIf { it > 0 }?.let { sid -> p.getString("source_mode_$sid", null)?.let { return it } }
        return p.getString("global_mode", PLAYER_AUTO) ?: PLAYER_AUTO
    }
    private fun setChannelMode(channelId: Long, mode: String) { if (channelId > 0) getSharedPreferences(PLAYER_PREFS, MODE_PRIVATE).edit().putString("channel_mode_$channelId", mode).apply() }
    private fun clearChannelMode(channelId: Long) { if (channelId > 0) getSharedPreferences(PLAYER_PREFS, MODE_PRIVATE).edit().remove("channel_mode_$channelId").apply() }
    private fun setSourceMode(mode: String) { currentSourceId?.takeIf { it > 0 }?.let { getSharedPreferences(PLAYER_PREFS, MODE_PRIVATE).edit().putString("source_mode_$it", mode).apply() } }
    private fun isPlayableUrl(url: String) = url.startsWith("http://", true) || url.startsWith("https://", true) || url.startsWith("rtmp://", true) || url.startsWith("rtsp://", true)
    private fun showError(msg: String) { errorView.text = msg; errorView.visibility = View.VISIBLE; Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    private fun controlButton(text: String, click: () -> Unit): TextView = TextView(this).apply { this.text = text; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER; isFocusable = true; isClickable = true; setPadding(dp(13), dp(9), dp(13), dp(9)); background = selectablePill(Color.rgb(22,52,72), Color.rgb(62, 98, 142)); setOnClickListener { click() }; layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(5),0,dp(5),0) } }
    private fun pill(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(18).toFloat(); setStroke(dp(1), Color.argb(90,255,255,255)) }
    private fun selectablePill(normal: Int, focused: Int) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), GradientDrawable().apply { setColor(Color.rgb(50, 130, 210)); cornerRadius = dp(18).toFloat(); setStroke(dp(2), Color.WHITE) })
        addState(intArrayOf(android.R.attr.state_focused), GradientDrawable().apply { setColor(focused); cornerRadius = dp(18).toFloat(); setStroke(dp(3), Color.rgb(210, 235, 255)) })
        addState(intArrayOf(), GradientDrawable().apply { setColor(normal); cornerRadius = dp(18).toFloat(); setStroke(dp(1), Color.argb(120,255,255,255)) })
    }

    companion object {
        private const val FAVORITES_GROUP = "★ Favoriler"
        private const val PLAYER_PREFS = "player_mode_prefs_v12"
        private const val PLAYER_AUTO = "AUTO"
        private const val PLAYER_INTERNAL = "INTERNAL"
        private const val PLAYER_WUFFY = "WUFFY"
        private const val PLAYER_EXTERNAL = "EXTERNAL"
        private const val WUFFY_PACKAGE = "co.wuffy.player"
        const val EXTRA_STREAM_URL = "stream_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_CHANNEL_ID = "channel_id"
        const val EXTRA_SOURCE_ID = "source_id"
        const val EXTRA_AUTO_SHOW_GROUPS = "auto_show_groups"
    }
}
