package com.apklarim.iptvstarter.ui

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.apklarim.iptvstarter.data.local.AppDatabase
import com.apklarim.iptvstarter.data.local.ChannelEntity
import com.apklarim.iptvstarter.data.local.SourceEntity
import com.apklarim.iptvstarter.data.repository.IptvRepository
import com.apklarim.iptvstarter.player.PlayerActivity
import com.apklarim.iptvstarter.ui.adapters.SourceAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var repository: IptvRepository? = null
    private lateinit var root: FrameLayout
    private lateinit var statusText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var sourceAdapter: SourceAdapter
    private lateinit var m3uTab: TextView
    private lateinit var xtreamTab: TextView
    private lateinit var magTab: TextView
    private var exitBackArmed = false
    private var inSettings = false
    private var currentTab = TAB_M3U

    private val openM3uFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        showM3uFileNameDialog(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching { enableImmersiveFullscreen() }
        root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(6, 14, 28)) }
        setContentView(root)
        showHome()
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val db = AppDatabase.get(this@MainActivity)
                    IptvRepository(db.channelDao(), db.sourceDao())
                }
            }
            result.onSuccess { repository = it; statusText.text = "Hazır" }
                .onFailure { statusText.text = "Başlatma hatası: ${it.message ?: it.javaClass.simpleName}" }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) runCatching { enableImmersiveFullscreen() }
    }

    private fun showHome() {
        inSettings = false
        root.removeAllViews()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = verticalBg()
        }
        val settings = TextView(this).apply {
            text = "⚙ Ayarlar"
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            isFocusable = true
            isClickable = true
            setPadding(dp(13), dp(9), dp(13), dp(9))
            background = selectableBg(Color.rgb(22, 38, 62), Color.rgb(9, 175, 205), dp(20))
            setOnClickListener { showSettings() }
        }
        root.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(settings, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(14), dp(14), 0) })

        val logo = TextView(this).apply {
            text = "◈ IPTV PRO"
            setTextColor(Color.WHITE)
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setShadowLayer(9f, 3f, 3f, Color.rgb(0, 220, 205))
        }
        val subtitle = TextView(this).apply {
            text = "Kanallar, filmler ve diziler gruplarıyla player içinde açılır"
            setTextColor(Color.rgb(180, 204, 226))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(22))
        }
        box.addView(logo, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(subtitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(bigHomeButton("Canlı", ChannelEntity.MEDIA_LIVE))
        row.addView(bigHomeButton("Film", ChannelEntity.MEDIA_VOD))
        row.addView(bigHomeButton("Dizi", ChannelEntity.MEDIA_SERIES))
        box.addView(row)

        statusText = TextView(this).apply {
            text = "Ayarlar’dan link ekleyin. Sonra Canlı / Film / Dizi ile liste gruplarına girin."
            setTextColor(Color.rgb(158, 184, 210))
            gravity = Gravity.CENTER
            textSize = 14f
            setPadding(0, dp(24), 0, 0)
        }
        progress = ProgressBar(this).apply { visibility = View.GONE }
        box.addView(statusText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun bigHomeButton(title: String, type: String): TextView = TextView(this).apply {
        text = title
        setTextColor(Color.WHITE)
        textSize = 22f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        isFocusable = true
        isClickable = true
        setPadding(dp(22), dp(28), dp(22), dp(28))
        background = selectableBg(Color.rgb(16, 46, 70), Color.rgb(0, 210, 190), dp(28))
        layoutParams = LinearLayout.LayoutParams(0, dp(128), 1f).apply { setMargins(dp(7), dp(7), dp(7), dp(7)) }
        setOnClickListener { openFirstForType(type) }
    }

    private fun showSettings() {
        inSettings = true
        root.removeAllViews()
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(9))
            background = verticalBg()
        }
        root.addView(page, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "Ayarlar ve Linkler"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        top.addView(title)
        top.addView(smallButton("Geri") { showHome() })
        page.addView(top)

        val addButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(5)) }
        addButtons.addView(smallButton("+ M3U Link") { showM3uUrlDialog(null) })
        addButtons.addView(smallButton("+ M3U Dosya") { openM3uFile.launch(arrayOf("*/*")) })
        addButtons.addView(smallButton("+ Xtream") { showXtreamDialog(null) })
        addButtons.addView(smallButton("+ MAG") { showMagDialog(null) })
        addButtons.addView(smallButton("▶ Player") { showPlayerModeDialog() })
        page.addView(addButtons)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(7)) }
        m3uTab = tabButton("M3U") { selectTab(TAB_M3U) }
        xtreamTab = tabButton("Xtream") { selectTab(TAB_XTREAM) }
        magTab = tabButton("MAG") { selectTab(TAB_MAG) }
        tabs.addView(m3uTab, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        tabs.addView(xtreamTab, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        tabs.addView(magTab, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        page.addView(tabs)

        statusText = TextView(this).apply { text = "Linke dokununca player açılır. Uzun bas: yenile / düzelt / sil."; setTextColor(Color.rgb(180,202,226)); textSize = 13f }
        progress = ProgressBar(this).apply { visibility = View.GONE }
        page.addView(statusText)
        page.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(4)))

        sourceAdapter = SourceAdapter(
            onClick = { source -> source?.let { openSource(it.id, ChannelEntity.MEDIA_LIVE) } },
            onLongClick = { source -> showSourceActions(source) }
        )
        val sourceList = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = sourceAdapter
            setHasFixedSize(true)
            itemAnimator = null
            isVerticalScrollBarEnabled = true
            background = rounded(Color.rgb(9, 21, 38), Color.rgb(46, 76, 104), dp(18))
        }
        page.addView(sourceList, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        selectTab(currentTab)
    }

    private fun selectTab(tab: String) {
        currentTab = tab
        if (::m3uTab.isInitialized) {
            applyTabStyle(m3uTab, tab == TAB_M3U)
            applyTabStyle(xtreamTab, tab == TAB_XTREAM)
            applyTabStyle(magTab, tab == TAB_MAG)
        }
        refreshSources()
    }

    private fun openFirstForType(mediaType: String) {
        val repo = repository ?: run { Toast.makeText(this, "Uygulama hazırlanıyor", Toast.LENGTH_SHORT).show(); return }
        lifecycleScope.launch {
            val sources = withContext(Dispatchers.IO) { repo.sources() }
            val activeId = prefs().getLong(KEY_ACTIVE_SOURCE_ID, -1L).takeIf { it > 0 }
            val active = sources.firstOrNull { it.id == activeId } ?: sources.firstOrNull()
            if (active == null) Toast.makeText(this@MainActivity, "Önce Ayarlar’dan link ekleyin", Toast.LENGTH_LONG).show()
            else openSource(active.id, mediaType, autoShowGroups = true)
        }
    }

    private fun openSource(sourceId: Long, mediaType: String = ChannelEntity.MEDIA_LIVE, autoShowGroups: Boolean = false) {
        prefs().edit().putLong(KEY_ACTIVE_SOURCE_ID, sourceId).apply()
        if (::sourceAdapter.isInitialized) sourceAdapter.selectedId = sourceId
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_SOURCE_ID, sourceId)
            putExtra(PlayerActivity.EXTRA_MEDIA_TYPE, mediaType)
            putExtra(PlayerActivity.EXTRA_AUTO_SHOW_GROUPS, autoShowGroups)
        })
    }

    private fun refreshSources() {
        if (!::statusText.isInitialized) return
        lifecycleScope.launch {
            val repo = repository ?: return@launch
            val all = withContext(Dispatchers.IO) { repo.sources() }
            val filtered = when (currentTab) {
                TAB_XTREAM -> all.filter { it.type == SourceEntity.TYPE_XTREAM }
                TAB_MAG -> all.filter { it.type == SourceEntity.TYPE_MAG }
                else -> all.filter { it.type == SourceEntity.TYPE_M3U_URL || it.type == SourceEntity.TYPE_M3U_FILE }
            }
            sourceAdapter.selectedId = prefs().getLong(KEY_ACTIVE_SOURCE_ID, -1L).takeIf { it > 0 }
            sourceAdapter.submitList(filtered)
            statusText.text = if (filtered.isEmpty()) "Bu sekmede henüz link yok." else "${filtered.size} link hazır. Seçili link aktif kaynak olur."
        }
    }

    private fun showM3uUrlDialog(source: SourceEntity?) {
        val name = input("Link adı", source?.name ?: "")
        val url = input("M3U URL", source?.url ?: "")
        showForm("M3U Link ${if (source == null) "Ekle" else "Düzelt"}", listOf(name, url)) {
            val enteredUrl = url.text.toString().trim()
            val candidate = detectXtreamFromUrl(enteredUrl)
            if (candidate != null) {
                AlertDialog.Builder(this)
                    .setTitle("Xtream bağlantısı algılandı")
                    .setMessage("Bu link Xtream koduna uygun görünüyor. Nasıl kaydedilsin?")
                    .setPositiveButton("Xtream olarak") { _, _ ->
                        currentTab = TAB_XTREAM
                        runImport("Xtream liste alınıyor...") {
                            (repository ?: error("Veritabanı hazır değil")).importXtream(
                                name.text.toString(), candidate.server, candidate.username, candidate.password, source?.id
                            )
                        }
                    }
                    .setNegativeButton("M3U olarak") { _, _ ->
                        currentTab = TAB_M3U
                        runImport("M3U içe aktarılıyor...") {
                            (repository ?: error("Veritabanı hazır değil")).importM3uUrl(name.text.toString(), enteredUrl, source?.id)
                        }
                    }
                    .setNeutralButton("Vazgeç", null)
                    .show()
            } else {
                currentTab = TAB_M3U
                runImport("M3U içe aktarılıyor...") {
                    (repository ?: error("Veritabanı hazır değil")).importM3uUrl(name.text.toString(), enteredUrl, source?.id)
                }
            }
        }
    }

    private fun showM3uFileNameDialog(uri: Uri) {
        val defaultName = uri.lastPathSegment?.substringAfterLast('/') ?: "M3U Dosyası"
        val name = input("Dosya adı", defaultName)
        showForm("M3U Dosya Ekle", listOf(name)) {
            currentTab = TAB_M3U
            runImport("Dosya okunuyor...") {
                val content = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Dosya okunamadı")
                (repository ?: error("Veritabanı hazır değil")).importM3uFile(name.text.toString(), uri.toString(), content)
            }
        }
    }

    private fun showXtreamDialog(source: SourceEntity?) {
        val name = input("Link adı", source?.name ?: "")
        val server = input("Sunucu URL", source?.url ?: "")
        val username = input("Kullanıcı adı", source?.username ?: "")
        val password = input("Şifre", source?.password ?: "")
        showForm("Xtream ${if (source == null) "Ekle" else "Düzelt"}", listOf(name, server, username, password)) {
            currentTab = TAB_XTREAM
            runImport("Xtream liste alınıyor...") {
                (repository ?: error("Veritabanı hazır değil")).importXtream(name.text.toString(), server.text.toString(), username.text.toString(), password.text.toString(), source?.id)
            }
        }
    }

    private fun showMagDialog(source: SourceEntity?) {
        val name = input("Link adı", source?.name ?: "")
        val portal = input("Portal URL", source?.url ?: "")
        val mac = input("MAG MAC / cihaz kodu", source?.magMac ?: "")
        showForm("MAG ${if (source == null) "Ekle" else "Düzelt"}", listOf(name, portal, mac)) {
            lifecycleScope.launch {
                currentTab = TAB_MAG
                setBusy(true, "MAG kaynağı kaydediliyor...")
                runCatching {
                    withContext(Dispatchers.IO) {
                        if (source == null) (repository ?: error("Veritabanı hazır değil")).saveMag(name.text.toString(), portal.text.toString(), mac.text.toString())
                        else (repository ?: error("Veritabanı hazır değil")).updateSourceOnly(source.copy(name = name.text.toString(), url = portal.text.toString(), magMac = mac.text.toString()))
                    }
                }.onSuccess { Toast.makeText(this@MainActivity, "MAG kaynağı kaydedildi", Toast.LENGTH_SHORT).show(); refreshSources() }
                    .onFailure { statusText.text = "Hata: ${it.message}" }
                setBusy(false, "Hazır")
            }
        }
    }

    private fun showSourceActions(source: SourceEntity) {
        val options = mutableListOf("Düzelt", "Sil")
        if (source.type == SourceEntity.TYPE_M3U_FILE) options.add(0, "İsmini değiştir")
        if (source.type != SourceEntity.TYPE_MAG && source.type != SourceEntity.TYPE_M3U_FILE) options.add(0, "Yenile")
        AlertDialog.Builder(this).setTitle(source.name).setItems(options.toTypedArray()) { _, which ->
            when (options[which]) { "Yenile" -> refreshSource(source); "İsmini değiştir" -> renameSource(source); "Düzelt" -> editSource(source); "Sil" -> confirmDelete(source) }
        }.setNegativeButton("Vazgeç", null).show()
    }

    private fun editSource(source: SourceEntity) {
        when (source.type) {
            SourceEntity.TYPE_M3U_URL -> { currentTab = TAB_M3U; showM3uUrlDialog(source) }
            SourceEntity.TYPE_XTREAM -> { currentTab = TAB_XTREAM; showXtreamDialog(source) }
            SourceEntity.TYPE_MAG -> { currentTab = TAB_MAG; showMagDialog(source) }
            SourceEntity.TYPE_M3U_FILE -> renameSource(source)
            else -> Toast.makeText(this, "Bu kaynak türü düzenlenemiyor", Toast.LENGTH_LONG).show()
        }
    }

    private fun renameSource(source: SourceEntity) {
        val name = input("Link adı", source.name)
        showForm("İsmi değiştir", listOf(name)) {
            lifecycleScope.launch {
                runCatching {
                    withContext(Dispatchers.IO) { (repository ?: error("Veritabanı hazır değil")).updateSourceOnly(source.copy(name = name.text.toString().ifBlank { source.name })) }
                }.onSuccess { refreshSources(); Toast.makeText(this@MainActivity, "İsim güncellendi", Toast.LENGTH_SHORT).show() }
                 .onFailure { statusText.text = "Hata: ${it.message}" }
            }
        }
    }


    private fun showPlayerModeDialog() {
        val labels = arrayOf("Otomatik", "Dahili ExoPlayer", "Wuffy Player", "Harici player seç")
        val values = arrayOf(PLAYER_AUTO, PLAYER_INTERNAL, PLAYER_WUFFY, PLAYER_EXTERNAL)
        val prefs = getSharedPreferences(PLAYER_PREFS, MODE_PRIVATE)
        val current = prefs.getString("global_mode", PLAYER_AUTO) ?: PLAYER_AUTO
        val checked = values.indexOf(current).takeIf { it >= 0 } ?: 0
        AlertDialog.Builder(this)
            .setTitle("Player Seçimi")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                prefs.edit().putString("global_mode", values[which]).apply()
                Toast.makeText(this, "Player: ${labels[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setMessage("Otomatik modda yayın önce dahili player ile denenir. Dahili player açamazsa Wuffy Player, Wuffy yoksa harici player seçimi açılır.")
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun refreshSource(source: SourceEntity) {
        when (source.type) {
            SourceEntity.TYPE_M3U_URL -> runImport("${source.name} yenileniyor...") { (repository ?: error("Veritabanı hazır değil")).importM3uUrl(source.name, source.url, source.id) }
            SourceEntity.TYPE_XTREAM -> runImport("${source.name} yenileniyor...") { (repository ?: error("Veritabanı hazır değil")).importXtream(source.name, source.url, source.username.orEmpty(), source.password.orEmpty(), source.id) }
            else -> Toast.makeText(this, "Bu kaynak türü otomatik yenilenemez", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmDelete(source: SourceEntity) {
        AlertDialog.Builder(this).setTitle("Kaynağı sil").setMessage("${source.name} ve içindeki kanallar silinsin mi?")
            .setPositiveButton("Sil") { _, _ -> lifecycleScope.launch { withContext(Dispatchers.IO) { (repository ?: error("Veritabanı hazır değil")).deleteSource(source) }; refreshSources() } }
            .setNegativeButton("Vazgeç", null).show()
    }

    private fun runImport(message: String, block: suspend () -> Int) {
        lifecycleScope.launch {
            setBusy(true, message)
            runCatching { withContext(Dispatchers.IO) { block() } }
                .onSuccess { count -> statusText.text = "$count öğe içe aktarıldı"; refreshSources() }
                .onFailure { statusText.text = "Hata: ${it.message}. Eski kayıt korunur." }
            setBusy(false, statusText.text.toString())
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (inSettings) { showHome(); return true }
            askExit(); return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun askExit() {
        if (!exitBackArmed) { exitBackArmed = true; Toast.makeText(this, "Çıkmak için geri tuşuna tekrar basın", Toast.LENGTH_SHORT).show(); root.postDelayed({ exitBackArmed = false }, 1800); return }
        AlertDialog.Builder(this).setTitle("Çıkış").setMessage("Uygulamadan çıkmak istiyor musunuz?").setPositiveButton("Evet") { _, _ -> finish() }.setNegativeButton("Hayır", null).show()
    }

    private fun detectXtreamFromUrl(raw: String): XtreamCandidate? = runCatching {
        val uri = Uri.parse(raw.trim())
        val username = uri.getQueryParameter("username")?.takeIf { it.isNotBlank() } ?: return null
        val password = uri.getQueryParameter("password")?.takeIf { it.isNotBlank() } ?: return null
        val scheme = uri.scheme ?: return null
        val authority = uri.encodedAuthority ?: return null
        val path = uri.encodedPath.orEmpty()
        val basePath = path.substringBeforeLast("/get.php", "")
        val server = "$scheme://$authority$basePath".trimEnd('/')
        XtreamCandidate(server, username, password)
    }.getOrNull()

    private fun smallButton(text: String, click: () -> Unit): TextView = TextView(this).apply {
        this.text = text; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; isFocusable = true; isClickable = true
        setPadding(dp(9), dp(7), dp(9), dp(7)); background = selectableBg(Color.rgb(18, 52, 76), Color.rgb(0, 205, 180), dp(15))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(4), 0, dp(4), 0) }
        setOnClickListener { click() }
    }

    private fun tabButton(text: String, click: () -> Unit): TextView = TextView(this).apply {
        this.text = text; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; isFocusable = true; isClickable = true; typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(10), dp(11), dp(10), dp(11)); setOnClickListener { click() }
    }

    private fun applyTabStyle(view: TextView, selected: Boolean) {
        view.background = rounded(if (selected) Color.rgb(0, 108, 128) else Color.rgb(18, 31, 49), if (selected) Color.rgb(0, 235, 210) else Color.rgb(55, 78, 104), dp(16))
    }

    private fun input(hint: String, value: String = "") = EditText(this).apply { this.hint = hint; setText(value); setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8)) }
    private fun showForm(title: String, fields: List<EditText>, onSave: () -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0); fields.forEach { addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(5), 0, dp(5)) }) } }
        AlertDialog.Builder(this).setTitle(title).setView(box).setPositiveButton("Kaydet") { _, _ -> onSave() }.setNegativeButton("Vazgeç", null).show()
    }
    private fun setBusy(busy: Boolean, text: String) { progress.visibility = if (busy) View.VISIBLE else View.GONE; statusText.text = text }
    private fun rounded(color: Int, stroke: Int, radius: Int) = GradientDrawable().apply { cornerRadius = radius.toFloat(); setColor(color); setStroke(dp(1), stroke) }
    private fun selectableBg(normal: Int, focused: Int, radius: Int) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), rounded(focused, Color.WHITE, radius))
        addState(intArrayOf(android.R.attr.state_focused), rounded(focused, Color.WHITE, radius))
        addState(intArrayOf(android.R.attr.state_selected), rounded(focused, Color.WHITE, radius))
        addState(intArrayOf(), rounded(normal, Color.rgb(70, 100, 130), radius))
    }
    private fun verticalBg() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.rgb(4, 11, 24), Color.rgb(8, 24, 42), Color.rgb(4, 9, 18)))

    private fun prefs() = getSharedPreferences("main_prefs_v11", MODE_PRIVATE)

    private data class XtreamCandidate(val server: String, val username: String, val password: String)

    companion object {
        private const val KEY_ACTIVE_SOURCE_ID = "active_source_id"
        private const val PLAYER_PREFS = "player_mode_prefs_v12"
        private const val PLAYER_AUTO = "AUTO"
        private const val PLAYER_INTERNAL = "INTERNAL"
        private const val PLAYER_WUFFY = "WUFFY"
        private const val PLAYER_EXTERNAL = "EXTERNAL"
        private const val TAB_M3U = "M3U"
        private const val TAB_XTREAM = "XTREAM"
        private const val TAB_MAG = "MAG"
    }
}
