# Mac için Gradle Sync Kurulumu

Bu proje için önerilen güvenli eşleşme:

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- compileSdk: 35
- targetSdk: 35

## Android Studio ayarı

1. Android Studio ile `IptvStarter` klasörünü aç.
2. `Settings / Preferences > Build, Execution, Deployment > Build Tools > Gradle` menüsüne gir.
3. `Gradle JDK` değerini `Embedded JDK 17` yap.
4. `File > Sync Project with Gradle Files` çalıştır.

## Android SDK ayarı

`Settings / Preferences > Languages & Frameworks > Android SDK` ekranında şunları kur:

- Android SDK Platform 35
- Android SDK Build-Tools 34.0.0 veya daha yeni 35.x build-tools
- Android SDK Platform-Tools

## Gradle Wrapper oluşturmak istersen

Bilgisayarında Gradle yüklüyse proje kökünde çalıştır:

```bash
gradle wrapper --gradle-version 8.9
./gradlew --version
./gradlew clean assembleDebug
```

Gradle yüklü değilse Mac üzerinde Homebrew ile:

```bash
brew install gradle
cd /path/to/IptvStarter
gradle wrapper --gradle-version 8.9
./gradlew clean assembleDebug
```

Not: Wrapper üretildikten sonra projeyi tekrar ZIP’leyip saklamak daha taşınabilir olur.


## Bu pakette düzeltilen olası build hatası

Önceki pakette `lifecycleScope` kullanıldığı halde `androidx.lifecycle:lifecycle-runtime-ktx` bağımlılığı eksikti. Bu paket `2.8.7` sürümünü ekler.

## Hâlâ hata alırsan

Android Studio altındaki `Build Output` ekranından ilk kırmızı hata satırını kopyala. En önemli satırlar genelde şunlardan biridir:

- `Unresolved reference ...`
- `Plugin ... was not found`
- `SDK location not found`
- `Android Gradle plugin requires Java 17`
- `compileSdk ... is not installed`
