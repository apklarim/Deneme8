# v11 Değişiklikleri

- Linke dokununca o link artık aktif kaynak olarak kaydedilir.
- Ana ekrandaki Canlı / Film / Dizi butonları artık aktif kaynağın listesini açar; eski linkten liste karışması engellenir.
- Kanal yükleme limiti 100.000'e çıkarıldı.
- Film / Dizi ayrımı M3U grup adlarında Türkçe/İngilizce anahtar kelimeleri de dikkate alacak şekilde iyileştirildi.
- M3U dosya kaynaklarında isim değiştirme eklendi.
- Kanal listesinin üstüne arama alanı eklendi.
- Kanal satırlarına favori yıldızı eklendi.
- Favoriler grubu kanal/grup listesinin en üstünde gösterilir.
- Seçili kanal kanal listesinde daha belirgin renkle görünür.
- Media3 ExoPlayer korunarak HLS/M3U8/TS desteği devam eder; RTSP modülü de eklendi. FFmpeg eklenmedi, böylece APK boyutu gereksiz büyümez.
