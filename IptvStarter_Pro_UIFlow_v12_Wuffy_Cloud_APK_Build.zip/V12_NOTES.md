# v12 - Otomatik Player + Wuffy Desteği

Bu sürümde dahili ExoPlayer yanında Wuffy/harici player akışı eklendi.

## Eklenenler

- Ayarlar ekranına `▶ Player` butonu eklendi.
- Global player seçimi:
  - Otomatik
  - Dahili ExoPlayer
  - Wuffy Player
  - Harici player seç
- Otomatik modda yayın önce dahili player ile denenir.
- Dahili player hata verirse Wuffy Player açılır.
- Wuffy yüklü değilse Android harici player seçimi açılır.
- Kanal uzun basma menüsüne şunlar eklendi:
  - Dahili player ile aç
  - Wuffy Player ile aç
  - Harici player seç
  - Bu kanal için her zaman Wuffy
  - Bu link için her zaman Wuffy
  - Bu kanal varsayılanını temizle
- Wuffy paket adı `co.wuffy.player` için Android 11+ paket görünürlüğü `<queries>` ile eklendi.

## Not

2'li / 4'lü çoklu ekran gömülü player olduğu için dahili ExoPlayer kullanır. Wuffy harici uygulama olarak açıldığı için çoklu ekran hücresinin içine gömülemez.
